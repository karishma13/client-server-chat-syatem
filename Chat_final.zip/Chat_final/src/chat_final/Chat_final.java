/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chat_final;
import java.io.*;
import java.net.*;


/**
 *
 * @author Karishma
 */
public class Chat_final
{

    public static void main(String[] args)throws Exception 
    {   
        
        Socket sock=new Socket("127.0.0.1",3000);
        //reading input from keyboard of client(keyboard object)
        BufferedReader keyboard=new BufferedReader(new InputStreamReader(System.in));
        //sending data to other client(pwrite object)
        OutputStream ostream=sock.getOutputStream();
        PrintWriter pwrite=new PrintWriter(ostream,true);
        //receiving data from server(recieve object)
        InputStream istream=sock.getInputStream();
        BufferedReader receive=new BufferedReader(new InputStreamReader(istream));
        
        System.out.println("Start your chatting! Have fun!!");
        
        String sendMessage,receiveMessage;
        
        while(true)
        {
            sendMessage=keyboard.readLine();
            pwrite.println(sendMessage);
            pwrite.flush();
            if((receiveMessage=receive.readLine())!=null)
            {
                System.out.println(receiveMessage);
            }    
        }
            
   }            
}
        
        
        
    

