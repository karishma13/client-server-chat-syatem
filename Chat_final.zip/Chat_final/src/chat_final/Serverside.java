


//author Karishma
import java.io.*;
import java.net.*;

public class Serverside 
{
    public static void main(String[] args)throws Exception
    {
        ServerSocket sersock=new ServerSocket(3000);
        System.out.println("Server ready for chatting");
        Socket sock=sersock.accept();
        
        //reading from keyboard(keyboard object of server)
        BufferedReader keyboard=new BufferedReader(new InputStreamReader(System.in));
        //sending to the client(pwrite object of server)
        OutputStream ostream=sock.getOutputStream();
        PrintWriter pwrite=new PrintWriter(ostream,true);
        //receiving from client
        InputStream istream=sock.getInputStream();
        BufferedReader receive=new BufferedReader(new InputStreamReader(istream));
         
        String sendMessage,receiveMessage;
        
        while(true)
        {
            //receiving message from the client
            if((receiveMessage=receive.readLine())!=null)
            {
                System.out.println(receiveMessage);
            }
            sendMessage=keyboard.readLine();
            pwrite.println(sendMessage);
            pwrite.flush();
            
        }   
    }
}   
    

